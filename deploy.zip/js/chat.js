// ============================================================
// Chat Module — Handles chat UI and message management
// ============================================================

import { generateResponse, isModelReady } from './ai-engine.js';
import { saveConversation, getConversation, getAllConversations } from './storage.js';
import { showToast } from './ui.js';

let currentConversation = null;
let chatHistory = [];
let isGenerating = false;

// Simple Markdown parser
function parseMarkdown(text) {
  let html = text;

  // Code blocks with language
  html = html.replace(/```(\w*)\n([\s\S]*?)```/g, (_, lang, code) => {
    const escapedCode = escapeHtml(code.trim());
    const langLabel = lang || 'code';
    return `<pre><div class="code-header"><span>${langLabel}</span><button class="copy-btn" onclick="window.__copyCode(this)">Copy</button></div><code class="language-${lang}">${highlightSyntax(escapedCode, lang)}</code></pre>`;
  });

  // Inline code
  html = html.replace(/`([^`]+)`/g, '<code>$1</code>');

  // Bold
  html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');

  // Italic
  html = html.replace(/\*(.+?)\*/g, '<em>$1</em>');

  // Headers
  html = html.replace(/^### (.+)$/gm, '<h4>$1</h4>');
  html = html.replace(/^## (.+)$/gm, '<h3>$1</h3>');
  html = html.replace(/^# (.+)$/gm, '<h2>$1</h2>');

  // Unordered lists
  html = html.replace(/^[*-] (.+)$/gm, '<li>$1</li>');
  html = html.replace(/(<li>.*<\/li>\n?)+/g, '<ul>$&</ul>');

  // Numbered lists
  html = html.replace(/^\d+\. (.+)$/gm, '<li>$1</li>');

  // Line breaks (but not inside pre/code)
  html = html.replace(/\n\n/g, '</p><p>');
  html = html.replace(/\n/g, '<br>');

  // Wrap in paragraphs if not already wrapped
  if (!html.startsWith('<')) html = '<p>' + html + '</p>';

  return html;
}

function escapeHtml(text) {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function highlightSyntax(code, lang) {
  // Basic syntax highlighting
  let highlighted = code;

  // Keywords
  const keywords = /\b(function|const|let|var|if|else|for|while|return|import|export|from|class|extends|new|this|async|await|try|catch|throw|switch|case|break|default|true|false|null|undefined|typeof|instanceof|yield|of|in|def|print|self|None|True|False|elif|except|finally|with|as|lambda|pass|raise|and|or|not|is)\b/g;
  highlighted = highlighted.replace(keywords, '<span class="hljs-keyword">$1</span>');

  // Strings (double and single quoted)
  highlighted = highlighted.replace(/(["'])((?:(?!\1|\\).|\\.)*?)\1/g, '<span class="hljs-string">$1$2$1</span>');

  // Numbers
  highlighted = highlighted.replace(/\b(\d+\.?\d*)\b/g, '<span class="hljs-number">$1</span>');

  // Comments (single line)
  highlighted = highlighted.replace(/(\/\/.*$|#.*$)/gm, '<span class="hljs-comment">$1</span>');

  // Function calls
  highlighted = highlighted.replace(/\b(\w+)\s*\(/g, '<span class="hljs-function">$1</span>(');

  return highlighted;
}

// Copy code helper
window.__copyCode = function(btn) {
  const code = btn.closest('pre').querySelector('code').textContent;
  navigator.clipboard.writeText(code).then(() => {
    btn.textContent = 'Copied!';
    setTimeout(() => btn.textContent = 'Copy', 2000);
  });
};

function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
}

function createMessageEl(role, content, isStreaming = false) {
  const div = document.createElement('div');
  div.className = `message ${role}`;

  const avatar = document.createElement('div');
  avatar.className = 'message-avatar';
  avatar.textContent = role === 'user' ? '🧑' : '✨';

  const contentDiv = document.createElement('div');
  contentDiv.className = 'message-content';

  if (isStreaming) {
    contentDiv.innerHTML = '<div class="typing-indicator"><span></span><span></span><span></span></div>';
  } else {
    contentDiv.innerHTML = parseMarkdown(content);
  }

  div.appendChild(avatar);
  div.appendChild(contentDiv);
  return div;
}

function scrollToBottom(container) {
  requestAnimationFrame(() => {
    container.scrollTop = container.scrollHeight;
  });
}

export function initChat() {
  const chatInput = document.getElementById('chat-input');
  const btnSend = document.getElementById('btn-send');
  const chatContainer = document.getElementById('chat-messages');
  const btnNewChat = document.getElementById('btn-new-chat');

  // Auto-resize textarea
  chatInput.addEventListener('input', () => {
    chatInput.style.height = 'auto';
    chatInput.style.height = Math.min(chatInput.scrollHeight, 120) + 'px';
    btnSend.disabled = !chatInput.value.trim();
  });

  // Send on Enter (not Shift+Enter)
  chatInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage('chat');
    }
  });

  btnSend.addEventListener('click', () => sendMessage('chat'));

  // New chat
  btnNewChat.addEventListener('click', () => {
    newConversation();
  });

  // Quick actions
  document.querySelectorAll('#panel-chat .quick-action-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      chatInput.value = btn.dataset.prompt;
      chatInput.dispatchEvent(new Event('input'));
      sendMessage('chat');
    });
  });

  // Start with a fresh conversation
  newConversation();
}

function newConversation() {
  currentConversation = {
    id: generateId(),
    messages: [],
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };
  chatHistory = [];
  const container = document.getElementById('chat-messages');
  const welcomeCard = document.getElementById('welcome-card');

  // Remove all messages but keep welcome card
  container.innerHTML = '';
  if (welcomeCard) {
    container.appendChild(welcomeCard.cloneNode(true));
    // Re-attach quick action listeners
    container.querySelectorAll('.quick-action-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const chatInput = document.getElementById('chat-input');
        chatInput.value = btn.dataset.prompt;
        chatInput.dispatchEvent(new Event('input'));
        sendMessage('chat');
      });
    });
  }
}

export async function sendMessage(mode) {
  if (isGenerating) return;

  const inputId = mode === 'chat' ? 'chat-input' : 'code-input';
  const containerId = mode === 'chat' ? 'chat-messages' : 'code-messages';
  const input = document.getElementById(inputId);
  const container = document.getElementById(containerId);

  const text = input.value.trim();
  if (!text) return;

  if (!isModelReady()) {
    showToast('Please load an AI model first in Settings', 'error');
    return;
  }

  // Hide welcome card
  const welcomeCard = container.querySelector('.welcome-card');
  if (welcomeCard) welcomeCard.style.display = 'none';

  // Add user message
  const userMsg = createMessageEl('user', text);
  container.appendChild(userMsg);
  scrollToBottom(container);

  // Clear input
  input.value = '';
  input.style.height = 'auto';
  const sendBtn = document.getElementById(mode === 'chat' ? 'btn-send' : 'btn-send-code');
  sendBtn.disabled = true;

  // Add typing indicator
  const assistantMsg = createMessageEl('assistant', '', true);
  container.appendChild(assistantMsg);
  scrollToBottom(container);

  isGenerating = true;

  // Build messages for AI
  const systemPrompt = mode === 'code'
    ? 'You are an expert software developer. When asked to write code, provide clean, well-commented code with explanations. Use markdown code blocks with language identifiers (e.g., ```python). Be concise but thorough.'
    : 'You are NeuroX, a helpful, friendly, and knowledgeable AI assistant. Provide clear, concise, and accurate responses. Use markdown formatting when appropriate.';

  chatHistory.push({ role: 'user', content: text });

  const messages = [
    { role: 'system', content: systemPrompt },
    ...chatHistory.slice(-10), // Keep last 10 messages for context
  ];

  try {
    const contentDiv = assistantMsg.querySelector('.message-content');
    let finalResponse = '';

    await generateResponse(messages, (currentText) => {
      finalResponse = currentText;
      contentDiv.innerHTML = parseMarkdown(currentText);
      scrollToBottom(container);
    });

    chatHistory.push({ role: 'assistant', content: finalResponse });

    // Save conversation
    if (currentConversation) {
      currentConversation.messages = chatHistory;
      currentConversation.updatedAt = Date.now();
      await saveConversation(currentConversation);
    }

  } catch (err) {
    const contentDiv = assistantMsg.querySelector('.message-content');
    contentDiv.innerHTML = `<p style="color: var(--danger);">⚠️ ${escapeHtml(err.message)}</p>`;
    showToast('Error generating response', 'error');
  }

  isGenerating = false;
}

export function initCodeChat() {
  const codeInput = document.getElementById('code-input');
  const btnSend = document.getElementById('btn-send-code');

  codeInput.addEventListener('input', () => {
    codeInput.style.height = 'auto';
    codeInput.style.height = Math.min(codeInput.scrollHeight, 120) + 'px';
    btnSend.disabled = !codeInput.value.trim();
  });

  codeInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage('code');
    }
  });

  btnSend.addEventListener('click', () => sendMessage('code'));

  // Quick actions
  document.querySelectorAll('#panel-code .quick-action-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      codeInput.value = btn.dataset.prompt;
      codeInput.dispatchEvent(new Event('input'));
      sendMessage('code');
    });
  });
}
